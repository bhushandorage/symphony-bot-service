package com.example.symphonybot.service;

import com.symphony.bdk.core.service.message.MessageService;
import com.symphony.bdk.core.service.user.UserService;
import com.symphony.bdk.gen.api.model.V4User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class SymphonyBotService {

    private final MessageService messageService;
    private final UserService userService;

    public void sendMessageToRoom(String streamId, String message) {
        try {
            messageService.send(streamId, "<messageML>" + message + "</messageML>");
            log.info("Sent message to room {}", streamId);
        } catch (Exception e) {
            log.error("Error sending to room", e);
        }
    }

    public void sendMessageToUser(String email, String message) {
        try {
            V4User user = userService.getUserByEmail(email, false);
            String imStreamId = userService.createInstantMessage(user.getUserId()).getStreamId();
            messageService.send(imStreamId, "<messageML>" + message + "</messageML>");
            log.info("Sent message to user {}", email);
        } catch (Exception e) {
            log.error("Error sending to user", e);
        }
    }
}
