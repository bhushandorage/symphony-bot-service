package com.example.symphonybot.listener;

import com.symphony.bdk.core.event.RealTimeEventListener;
import com.symphony.bdk.gen.api.model.V4MessageSent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MessageListener implements RealTimeEventListener<V4MessageSent> {

    @Override
    public void onEvent(V4MessageSent event) {
        String messageText = event.getMessage().getMessage();
        String sender = event.getMessage().getUser().getDisplayName();
        String streamId = event.getMessage().getStream().getStreamId();

        log.info("Received message in stream {}: [{}]: {}", streamId, sender, messageText);
    }
}
