package com.example.symphonybot.controller;

import com.example.symphonybot.service.SymphonyBotService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
public class SymphonyMessageController {

    private final SymphonyBotService symphonyBotService;

    @PostMapping("/room")
    public String sendToRoom(@RequestParam String streamId, @RequestParam String message) {
        symphonyBotService.sendMessageToRoom(streamId, message);
        return "Message sent to room: " + streamId;
    }

    @PostMapping("/user")
    public String sendToUser(@RequestParam String email, @RequestParam String message) {
        symphonyBotService.sendMessageToUser(email, message);
        return "Message sent to user: " + email;
    }
}
