# ServiceNow Update Set Automation

## 🧩 Features
- Upload ServiceNow update sets from GitHub using Ansible or GitHub Actions.
- Secure credential management with GitHub Secrets or Ansible Vault.

## 🚀 Ansible Usage

```bash
ansible-playbook playbook.yml
```

(If using Vault: `ansible-playbook playbook.yml --ask-vault-pass`)

## 🔄 GitHub Action

- Go to **Actions → Deploy ServiceNow Update Set**
- Click **Run workflow**
- Enter the XML filename (e.g. `incident-fix-v1.xml`)

## 🔐 GitHub Secrets Needed
- `SN_USERNAME`
- `SN_PASSWORD`
- `SN_INSTANCE` (e.g., `https://your-instance.service-now.com`)
